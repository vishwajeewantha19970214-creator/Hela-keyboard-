import 'package:flutter/material.dart';
import '../widgets/keyboard_widget.dart';
import '../widgets/emoji_bar_widget.dart';

class HomeScreen extends StatelessWidget {
  final VoidCallback toggleTheme;
  HomeScreen({required this.toggleTheme});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("AI Keyboard"),
        actions: [
          IconButton(
            icon: Icon(Icons.brightness_6),
            onPressed: toggleTheme,
          ),
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: () => Navigator.pushNamed(context, '/settings'),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(child: Text("Tap below to type with AI Keyboard")),
          ),
          EmojiBarWidget(),
          KeyboardWidget(),
        ],
      ),
    );
  }
}