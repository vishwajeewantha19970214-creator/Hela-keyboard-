import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  final VoidCallback toggleTheme;
  SettingsScreen({required this.toggleTheme});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Settings")),
      body: ListView(
        children: [
          ListTile(
            title: Text("Dark/Light Theme"),
            trailing: Switch(value: false, onChanged: (_) => toggleTheme()),
          ),
          ListTile(
            title: Text("Manage Languages"),
            subtitle: Text("Sinhala, English, Singlish + Download others"),
          ),
          ListTile(
            title: Text("Enable Biometrics"),
            trailing: Icon(Icons.fingerprint),
          ),
        ],
      ),
    );
  }
}