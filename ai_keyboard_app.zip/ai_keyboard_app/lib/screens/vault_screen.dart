import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';

class VaultScreen extends StatefulWidget {
  @override
  _VaultScreenState createState() => _VaultScreenState();
}

class _VaultScreenState extends State<VaultScreen> {
  List<String> hiddenFiles = [];

  Future<void> pickAndHideFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      setState(() {
        hiddenFiles.add(result.files.single.name);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Hidden Vault")),
      body: ListView.builder(
        itemCount: hiddenFiles.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Icon(Icons.lock),
            title: Text(hiddenFiles[index]),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: pickAndHideFile,
        child: Icon(Icons.add),
      ),
    );
  }
}