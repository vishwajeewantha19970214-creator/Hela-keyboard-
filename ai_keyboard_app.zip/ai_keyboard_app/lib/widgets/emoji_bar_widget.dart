import 'package:flutter/material.dart';

class EmojiBarWidget extends StatelessWidget {
  final List<String> emojis = ["😀", "😂", "😍", "😎", "🙏", "🔥", "❤️"];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: emojis
            .map((emoji) => Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(emoji, style: TextStyle(fontSize: 28)),
                ))
            .toList(),
      ),
    );
  }
}