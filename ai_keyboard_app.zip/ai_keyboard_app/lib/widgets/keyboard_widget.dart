import 'package:flutter/material.dart';
import '../services/ai_prediction_engine.dart';

class KeyboardWidget extends StatefulWidget {
  @override
  _KeyboardWidgetState createState() => _KeyboardWidgetState();
}

class _KeyboardWidgetState extends State<KeyboardWidget> {
  String typedText = "";

  void addText(String char) {
    setState(() {
      typedText += char;
    });
  }

  void deleteText() {
    setState(() {
      if (typedText.isNotEmpty) {
        typedText = typedText.substring(0, typedText.length - 1);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    List<String> suggestions = AIPredictionEngine.getPredictions(typedText);
    return Column(
      children: [
        Row(
          children: suggestions
              .map((word) => Padding(
                    padding: EdgeInsets.all(4),
                    child: ElevatedButton(
                      onPressed: () => addText(" $word"),
                      child: Text(word),
                    ),
                  ))
              .toList(),
        ),
        TextField(
          decoration: InputDecoration(
            hintText: "Type here...",
            contentPadding: EdgeInsets.all(8),
          ),
          controller: TextEditingController(text: typedText),
          readOnly: true,
        ),
        Wrap(
          children: List.generate(26, (index) {
            String char = String.fromCharCode(index + 97);
            return InkWell(
              onTap: () => addText(char),
              child: Container(
                margin: EdgeInsets.all(4),
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(char.toUpperCase()),
              ),
            );
          }),
        ),
        ElevatedButton(onPressed: deleteText, child: Text("Delete")),
      ],
    );
  }
}