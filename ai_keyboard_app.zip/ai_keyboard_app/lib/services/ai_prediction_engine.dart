class AIPredictionEngine {
  static List<String> getPredictions(String text) {
    if (text.isEmpty) return ["Hello", "Hi", "Welcome"];
    if (text.endsWith("how")) return ["are", "is", "was"];
    if (text.endsWith("good")) return ["morning", "job", "luck"];
    return ["next", "suggestion", "word"];
  }
}