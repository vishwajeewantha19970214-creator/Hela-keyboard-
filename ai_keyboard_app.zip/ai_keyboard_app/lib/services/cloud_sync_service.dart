import 'package:cloud_firestore/cloud_firestore.dart';

class CloudSyncService {
  static final _db = FirebaseFirestore.instance;

  static Future<void> syncKeyword(String userId, String keyword) async {
    await _db.collection("users").doc(userId).set({
      "keywords": FieldValue.arrayUnion([keyword])
    }, SetOptions(merge: true));
  }
}